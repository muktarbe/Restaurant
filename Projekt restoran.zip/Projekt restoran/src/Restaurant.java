import java.util.Arrays;

public class Restaurant {
    public static int ID = 0;
    private int id;
    private String name;
    private String capacity;
    Reservation [] reservations;

    public Restaurant( String name, String capacity, Reservation[] reservations) {
        this.id = ++ID;
        this.name = name;
        this.capacity = capacity;
        this.reservations = reservations;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }

    public Reservation[] getReservations() {
        return reservations;
    }

    public void setReservations(Reservation[] reservations) {
        this.reservations = reservations;
    }

    @Override
    public String toString() {
        return
                "id = " + id +
                ", name = " + name + '\'' +
                ", capacity = " + capacity + '\'' +
                ", reservations = " + Arrays.toString(reservations) + "\n";
    }
}
