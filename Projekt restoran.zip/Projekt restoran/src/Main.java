import java.time.LocalDate;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        Customer customer1 = new Customer("Muktarbek");
        Customer customer2 = new Customer("Bilal");

        Reservation reservation1 = new Reservation(customer1, LocalDate.now());
        Reservation reservation2 = new Reservation(customer2, LocalDate.now());

        Reservation [] reservations1 = {reservation1,reservation2};

        Restaurant restaurant1 = new Restaurant("1+1=3","bishkek",reservations1);
        restaurantBooking(restaurant1);
    }
    public static void restaurantBooking(Restaurant restaurant1){
        for (int i = 0; i < restaurant1.reservations.length; i++) {
            if (restaurant1.reservations[i].getDate().equals(restaurant1.reservations[i].getDate())){
                System.err.println("Мы принимаем толька один клиэнт в один ден!😣");
                break;
            } else {
                System.out.println("Будер рады к вашему визиту");
            }

        }
    }
}