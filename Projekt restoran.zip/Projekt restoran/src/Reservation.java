import java.time.LocalDate;

public class Reservation {
    public static int ID = 0;
    private int id;
    private Customer customer;
    private LocalDate date;

    public Reservation( Customer customer, LocalDate date) {
        this.id = ++ID;
        this.customer = customer;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Reservation " +
                "id = " + id +
                ", customer = " + customer +
                ", date = " + date + "\n";
    }
}
